package com.Clinica.ProyectoClinica.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Clinica.ProyectoClinica.entity.Especialidad;


public interface EspecialidadRepository extends JpaRepository<Especialidad, Integer> {}
