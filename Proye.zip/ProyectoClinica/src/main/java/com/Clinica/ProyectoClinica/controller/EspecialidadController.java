package com.Clinica.ProyectoClinica.controller;

public class EspecialidadController {

}
